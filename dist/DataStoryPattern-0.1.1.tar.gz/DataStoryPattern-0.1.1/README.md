# DataStoryPatternLibrary
DataStorytelling Patterns developed as a part of Master Thesis Research
